2018-06-14  Sebastian Hübner <sh@kokolor.es>
  # 1.2

    * requests.lua (request): Added ability to use [1] as the URL if the only argument is a table (issue: #14)

2016-02-06  Louis Brauer <louis77@mac.com>

  # 1.1

    * requests.lua (make_request): Added HTTPS support using LuaSec
